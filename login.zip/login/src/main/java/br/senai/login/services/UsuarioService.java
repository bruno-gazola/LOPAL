package br.senai.login.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import br.senai.login.entities.Usuario;
import br.senai.login.repositories.UsuarioRepository;

@Service
public class UsuarioService {

	@Autowired
	private UsuarioRepository usuarioRepository;

	public List<Usuario> findAll() {
		return usuarioRepository.findAll();
	}

	public Usuario findById(Long id) {
		return usuarioRepository.findById(id).get();
	}

	public Usuario save(Usuario usuario) {
		return usuarioRepository.save(usuario);
	}

	public void delete(Long id) {
		usuarioRepository.deleteById(id);
	}
	
	public Usuario findByNomeUsuario(String nomeUsuario) {
		return usuarioRepository.findByNomeUsuario(nomeUsuario);
	}
	
	public Usuario autenticarPessoa(String email, String senha) {
		
		//Buscar no banco de dados um usuário que tenha o email informado 
		//Objeto sendo instanciado
		Usuario pessoa = usuarioRepository.findByEmail(email);
		
		//Verifica se o usuário foi encontrado e se a senha informada confere com a senha do usuário
		if(pessoa != null && pessoa.getSenha().equals(senha)) {
			//Se email e senha estiverem corretos, retorna o objeto usuarioAutentiicado
			return pessoa;
		}else {
			//Se o usuário não existir ou a senha não estiver correta, retorna null(falha na autenticação)
			return null;
		}
	}
}
